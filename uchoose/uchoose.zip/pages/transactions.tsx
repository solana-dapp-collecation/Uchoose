export default function Transactions(){
  return (<h1>TODO. Implement history of transactions later</h1>)
}
