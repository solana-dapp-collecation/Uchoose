export default function Logs(){
  return (<h1>TODO. Logs</h1>)
}
