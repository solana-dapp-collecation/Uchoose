export default function Views() {
    return (<h1>TODO. Views</h1>)
}
